package com.claim.insurance.controller;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.apache.tomcat.jni.Local;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.claim.insurance.entity.Claim;
import com.claim.insurance.service.ClaimService;

@RestController
public class ClaimGetController {

	@Autowired
	ClaimService service;

	@GetMapping("/getAllClaims")
	public List<Claim> getAllClaims() {
		return service.getAllClaims();
	}

	@GetMapping("/getAllClaimsByDate")
	public List<Claim> getAllClaims(@RequestParam String date) {
		LocalDate.parse(date, DateTimeFormatter.ofPattern("MMddyyyy"));
		return service.getAllClaims();
	}

}
